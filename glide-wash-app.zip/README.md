# Glide Car Wash — app concept

An iOS-style redesign of a car wash membership app: sign-up, wash pass with QR code, Add to Wallet, locations, plans and account. It is a clickable prototype; nothing is sent to a server.

- `index.html` — the prototype source.
- `docs/` — the installable web app (what GitHub Pages serves). Rebuild it after editing `index.html`:

```
python3 build.py
```

## Put it on your phone
1. In the repository on GitHub: **Settings → Pages → Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/docs`, then Save.
2. After a minute the site is at `https://<your-username>.github.io/<repo-name>/`.
3. On iPhone, open that link in Safari, tap **Share → Add to Home Screen**. On Android, open it in Chrome and tap **Install app**.

To rebrand, edit the `BRAND` line near the top of the script in `index.html`, then rebuild.

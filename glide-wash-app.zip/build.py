#!/usr/bin/env python3
"""Builds the installable web app in docs/ from index.html (the prototype source)."""
from pathlib import Path
root = Path(__file__).parent
src = (root / "index.html").read_text()
head = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0A5BE0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="apple-mobile-web-app-title" content="Glide">
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<link rel="icon" href="icons/icon-192.png">
<style>
  [hidden] { display: none !important; }
  /* Installed on a phone: respect the notch and home indicator. */
  @media (max-width: 520px), (max-height: 760px) and (max-width: 900px) {
    .screen { --top-inset: env(safe-area-inset-top, 0px) !important; }
    .sheet { bottom: calc(8px + env(safe-area-inset-bottom, 0px)); }
  }
</style>
</head>
<body>
"""
tail = """
<script>
if ("serviceWorker" in navigator) addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
</script>
</body>
</html>
"""
(root / "docs" / "index.html").write_text(head + src + tail)
print("built docs/index.html")
